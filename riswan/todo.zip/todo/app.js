const express = require('express');
const app = express();
// const db=require("./tododb.js");
const knex = require('knex')

const db = knex({
    client: 'pg',
    connection: {
        host: 'localhost',
        user: 'riswan1',
        password: 'Riswan@123',
        database: 'todo'
    }
});

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/" + "index.html");
});

app.get("/insert", (req, res) => {

    db('todolist').insert({ list: req.query['name'] }).returning("*").then(() => { res.redirect('/'); }).catch(err => {
        res.status(400).json({ message: 'failed' });
    });
    // var ris=req.query['name'];
    // res.redirect('back');
    // db.data.query(`insert into todolist values('${ris}');`,(res,err) => {
    //     if(err)
    //     {
    //         console.log(err);
    //     }
    //     else{
    //         console.log("success");
    //     }
    // });
});



app.listen(5454);